RSSI_6AP_Experiments: Database Folder
+ Nexus 4
* The original database: "UpdatedDatabase_24Jan2018_Full.csv"

-------------------------------------------------------------------------------
* For KNN
* The general format for csv data file is: X & Y & The list of RSSI
X | Y | RSSI Vector

----------------------------------------------------------------------------------
* For RNN Training
*****************************************
**** Input LSTM *************************
*****************************************
File       : Input_Location_RSSI_10points_365k
Description: + 365000 random trajectories
			 + Each trajectory has 9 history locations
			 (Use 9 history locations to predict the 10th one)
			 + Each location has 13 features: X,Y & 11 RSSI readings
Structure: 117 features (117 columns)
		   
X1 | Y1 | 11 RSSI of Location 2 .... X9 | Y9 | 11 RSSI of Location 10 
*****************************************
**** Output LSTM *************************
*****************************************
File       : Output_Location_RSSI_10points_365k
Description: + 365000 random trajectories
			 + 9 locations corresponding to the locations in the input 
Structure: 
X2 | Y2 | X3 | Y3 ... X10 | Y10

+ Nexus 5
